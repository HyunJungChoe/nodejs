const local = require('./localStrategy');

module.exports = (passport) => {
    passport.serializeUser((user, done) => {
        done(null, user.email);
    });

    passport.deserializeUser((email, done) => {
        const user = global.users[email]
        if (user) {
            done(null, user)
        } else {
            done("Not user")
        }
    });

    local(passport);
};
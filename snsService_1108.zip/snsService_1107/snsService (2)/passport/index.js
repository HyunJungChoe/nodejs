const local = require('./localStrategy');
const {User} = require('../models');

module.exports = (passport) => {
    passport.serializeUser((user, done) => {
        done(null, user.email);
    });

    // passport.deserializeUser((email, done) => {
    //     const user = global.users[email]
    //     if (user) {
    //         done(null, user)
    //     } else {
    //         done("Not user")
    //     }
    // });

    passport.deserializeUser((email, done) => {
        User,find({where : {id }})
        .then(User => done(null, user))
        .catch(err => done (err));
    });

    local(passport);
};